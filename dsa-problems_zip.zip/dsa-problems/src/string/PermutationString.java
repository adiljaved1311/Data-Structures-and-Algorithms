package string;

public class PermutationString {

	public static void main(String[] args) {
		
	}
	
}
