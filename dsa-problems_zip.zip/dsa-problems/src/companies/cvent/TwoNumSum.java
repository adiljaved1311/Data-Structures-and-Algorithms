package companies.cvent;

public class TwoNumSum {
    public static void main(String[] args) {
        int arr[] = {2,5,7,3,9,8};
        int sum = 8;
    }

    // Given an integer array and a sum find 2 numbers in array whose sum is equal to given number
    private static boolean twoNumSum(int arr[]){
        return false;

    }
}
