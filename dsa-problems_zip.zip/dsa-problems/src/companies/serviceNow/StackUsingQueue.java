package companies.serviceNow;

import queue.LinkedListQueue;

import java.util.Queue;

public class StackUsingQueue {
    Queue<Object> q1 = (Queue<Object>) new LinkedListQueue<Object>();

}
