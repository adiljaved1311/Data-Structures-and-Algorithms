package companies.serviceNow;

public class Test123 {
    public static void main(String[] args) {
        int arr[] = {1,2};
    }
}
