package companies.oracle;

public class BinarySort {
}
