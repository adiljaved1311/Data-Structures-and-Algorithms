package companies.paytm;

public class CountFrequency {
    public static void main(String[] args) {
        int arr[] = {2, 3, 3, 2, 5};
    }
    private static void countFrequency(int arr[]){

    }
}
