package companies.paytm;

public class MergeSort {
    public static void main(String[] args) {
        int arr[] = {2,4,8,7,1,3,5,6};
    }

    private static void mergeSort(int arr[]){

    }
}
