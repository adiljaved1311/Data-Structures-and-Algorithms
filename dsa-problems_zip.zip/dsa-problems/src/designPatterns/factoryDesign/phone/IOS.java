package designPatterns.factoryDesign.phone;

public class IOS implements OS {
    public void spec(){
        System.out.println("Most Secure OS IOS");
    }
}
