package designPatterns.factoryDesign.phone;

public interface OS {
    public void spec();
}
