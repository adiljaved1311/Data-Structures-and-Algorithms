package designPatterns.factoryDesign.phone;

public class Android implements OS{
    public void spec(){
        System.out.println("Most Powerful OS Android");
    }
}
