package designPatterns.factoryDesign.phone;

public class Windows implements OS {
    public void spec(){
        System.out.println("Most Used OS Windows");
    }
}
