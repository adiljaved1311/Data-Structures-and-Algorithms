package array;

public class Mutliplication {

	public static void main(String[] args) {
		//int a = 15, b = 3;
	}
	
	public static int multiplication(int a, int b) {
		//int result = 0;
		
		return 0;
	}
}
