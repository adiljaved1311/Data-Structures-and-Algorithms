package pattern_number;

public class P4 {

	public static void main(String[] args) 
	{
		p4(5);
	}
	public static void p4(int n)
	{
		
	}
}
/*
   1
  212
 32123
4321234
 32123
  212
   1
*/