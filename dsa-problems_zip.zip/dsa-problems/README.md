# Problems on Data Structure and Algorithms.

This repository contains programming questions on data structure and algorithms important for interview. The language used is Java.



### Topics

1. Array
2. LinkedList
3. Stack
4. Queue
5. Recursion
6. String
7. Tree
8. Matrix
9. OOP
10. Pattern 
11. Collection

 

